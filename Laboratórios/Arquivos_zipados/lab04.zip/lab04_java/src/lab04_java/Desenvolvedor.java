package lab04_java;

public interface Desenvolvedor {
	String getLinguagem_principal();
	void setLinguagem_principal(String linguagemPrin);
	String projetos_realizados(String linguagemPrin);
}
