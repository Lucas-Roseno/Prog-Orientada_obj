package lab04_java;

public interface Gerente {
	int getNumero_de_Equipes();
	void setNumero_de_equipes(int numero_de_equipes);
	float bonus(float numEquipes);
}
