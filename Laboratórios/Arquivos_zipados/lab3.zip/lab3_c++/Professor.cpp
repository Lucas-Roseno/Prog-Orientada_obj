#include "Professor.hpp"

string Professor::getTitulacao()
{
    return titulacao;
}
void Professor::setTitulacao(string titulacao)
{
    this->titulacao = titulacao;
}
string Professor::getCurso()
{
    return curso;
}
void Professor::setCurso(string curso)
{
    this->curso = curso;
}