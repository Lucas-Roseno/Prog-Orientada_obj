/**
 * 
 */
/**
 * 
 */
module lab05_java {
}