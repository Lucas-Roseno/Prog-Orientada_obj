#include "ModuloComAstronauta.hpp"

ModuloComAstronauta::ModuloComAstronauta(char tipo): Modulo(tipo){};

bool ModuloComAstronauta::podeAcessar(){
    return true;
}